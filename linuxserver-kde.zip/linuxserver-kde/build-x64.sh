#!/bin/bash

# 変数設定
DOCKERFILE="linuxserver-kde-x64.dockerfile"
IMAGE_NAME="webtop-kde"
VERSION="1.0.0"
ARCH="x64"
BUILD_DATE=$(date -u +'%Y-%m-%dT%H:%M:%SZ')

# カラー設定
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo "=========================================="
echo "Building ${IMAGE_NAME}:${ARCH}-${VERSION}"
echo "=========================================="
echo "Dockerfile: ${DOCKERFILE}"
echo "Build Date: ${BUILD_DATE}"
echo "Version: ${VERSION}"
echo "=========================================="

# 必要なファイルの存在確認
if [ ! -f "${DOCKERFILE}" ]; then
    echo -e "${RED}Error: ${DOCKERFILE} not found!${NC}"
    exit 1
fi

if [ ! -d "alpine-root" ] || [ ! -d "ubuntu-root" ] || [ ! -d "kde-root" ]; then
    echo -e "${RED}Error: Required root directories not found!${NC}"
    exit 1
fi

if [ ! -f "sources.list" ]; then
    echo -e "${RED}Error: sources.list not found!${NC}"
    exit 1
fi

if [ ! -d "patches" ] || [ ! -f "patches/21-xvfb-dri3.patch" ]; then
    echo -e "${RED}Error: patches directory or patch file not found!${NC}"
    exit 1
fi

# ビルド実行
set -o pipefail
docker build \
  -f ${DOCKERFILE} \
  --build-arg BUILD_DATE="${BUILD_DATE}" \
  --build-arg VERSION="${VERSION}" \
  --progress=plain \
  -t ${IMAGE_NAME}:${ARCH}-${VERSION} \
  -t ${IMAGE_NAME}:${ARCH}-latest \
  -t ${IMAGE_NAME}:${ARCH}-latest \
  . 2>&1 | tee build-${ARCH}-${VERSION}.log

# ビルド成功確認
BUILD_STATUS=${PIPESTATUS[0]}
if [ $BUILD_STATUS -eq 0 ]; then
  echo -e "${GREEN}=========================================="
  echo -e "Build successful!"
  echo -e "==========================================${NC}"
  echo ""
  echo "Created images:"
  docker images | grep ${IMAGE_NAME}
  echo ""
  echo "To run the container:"
  echo "docker run -d -p 3000:3000 -p 3001:3001 -v \$(pwd)/config:/config ${IMAGE_NAME}:${ARCH}-latest"
else
  echo -e "${RED}=========================================="
  echo -e "Build failed!"
  echo -e "==========================================${NC}"
  echo "Check build-${ARCH}-${VERSION}.log for details"
  exit 1
fi
